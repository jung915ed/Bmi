package com.example.bmi;

public class tester {
    public static void main(String[] args) {

    }
}
